package com.cg.ems.service;

public interface IAdminService {
	
	

}
