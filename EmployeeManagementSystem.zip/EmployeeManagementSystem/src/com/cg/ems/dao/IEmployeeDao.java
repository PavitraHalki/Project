package com.cg.ems.dao;

import java.util.List;


public interface IEmployeeDao {

	
}
