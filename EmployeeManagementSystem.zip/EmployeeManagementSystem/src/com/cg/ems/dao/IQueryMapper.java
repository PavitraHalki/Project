package com.cg.ems.dao;

public interface IQueryMapper {

	String GET_USER = null;

}
